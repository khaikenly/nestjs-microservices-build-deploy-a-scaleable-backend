import * as _ from 'lodash';

export const formatResource = (response: any) => {
  return {
    status: 'success',
    data: response,
  };
};
