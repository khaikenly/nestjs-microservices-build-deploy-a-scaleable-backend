export const AUTH_SERVICE = 'auth';
